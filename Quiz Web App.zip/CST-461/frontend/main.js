function teacherLogin() {
    var username = document.getElementById("teacherUsername").value;
    var password = document.getElementById("teacherPassword").value;

    fetch('/teacher-login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
        redirect: 'follow',
    })
    .then(response => {
        if (response.redirected) {
            window.location.href = '/teacherDashboard';
        } else {
            return response.text();
        }
    })
    .then(message => {
        if (message) {
            alert(message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function studentLogin() {
    const studentUsername = document.getElementById('studentUsername').value;
    const studentPassword = document.getElementById('studentPassword').value;

    fetch('/student-login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ studentUsername, studentPassword }),
    })
    .then(response => {
        if (response.ok) {
            return response.json();
        } else {
            throw new Error('Invalid username or password');
        }
    })
    .then(data => {
        if (data.redirectUrl) {
            window.location.href = data.redirectUrl;
        }
    })
    .catch((error) => {
        alert(error.message);
    });
}