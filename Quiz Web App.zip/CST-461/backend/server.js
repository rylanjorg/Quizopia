const os = require('os');
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const app = express();
const bodyParser = require('body-parser');

app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // set to true if your app is on https
}));

app.use(passport.initialize());
app.use(passport.session());

app.use(express.json()); // for parsing application/json
app.use(express.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());

const fs = require('fs');
const usersFilePath = './users.json';

app.post('/register', function(req, res) {
    const { username, password } = req.body;

    fs.readFile(usersFilePath, function(err, data) {
        if (err) throw err;

        const users = JSON.parse(data);

        if (users[username]) {
            res.status(400).send('Username already exists');
        } else {
            users[username] = { password: password };
            fs.writeFile(usersFilePath, JSON.stringify(users), function(err) {
                if (err) throw err;

                res.status(200).send('User registered');
            });
        }
    });
});

app.post('/saveQuiz', checkTeacherLoggedIn, function(req, res) {
    const quizData = req.body;
    let filePath = path.join(__dirname, './quizzes.json');

    fs.readFile(filePath, 'utf8', function(err, data) {
        if (err) {
            return res.status(500).send('An error occurred reading the file.');
        }

        const quizzes = JSON.parse(data || '[]');
        quizzes.push(quizData);

        fs.writeFile(filePath, JSON.stringify(quizzes, null, 2), function(err) {
            if (err) {
                return res.status(500).send('An error occurred writing to the file.');
            }

            res.send('Quiz saved successfully.');
        });
    });
});

app.post('/student-login', function(req, res) {
    const { studentUsername: username, studentPassword: password } = req.body;

    fs.readFile('users.json', 'utf8', function(err, data) {
        if (err) {
            console.log(err);
            res.status(500).send('Server error');
            return;
        }

        const users = JSON.parse(data);

        if (users[username] && users[username].password === password) {
            req.session.user = username;
            req.session.role = 'student';
            res.json({ redirectUrl: '/studentDashboard' });
        } else {
            res.status(400).send('Invalid username or password');
        }
    });
});

passport.use(new LocalStrategy(
    function(username, password, done) {
        fs.readFile(usersFilePath, function(err, data) {
            if (err) throw err;

            const users = JSON.parse(data);

            if (!users[username]) {
                return done(null, false, { message: 'Incorrect username.' });
            }

            if (password === users[username].password) {
                return done(null, username);
            } else {
                return done(null, false, { message: 'Incorrect password.' });
            }
        });
    }
));

passport.serializeUser(function(user, done) {
    done(null, user);
});

passport.deserializeUser(function(id, done) {
    done(null, id);
});


/*app.post('/login', passport.authenticate('local', { failureRedirect: '/login' }), function(req, res) {
    res.redirect('/');
});*/


// At the top of your server.js file, create an object to store the quiz sessions
let quizSessions = {};

// Then, add the /createQuizSession route
app.post('/createQuizSession', function(req, res) {
    // Get the code and quizId from the request body
    let code = req.body.code;
    let quizId = req.body.quizId;

    // Check if the code is already in use
    if (quizSessions[code]) {
        res.status(400).send('Code is already in use');
        return;
    }

    // Create a new quiz session with the quizId and an empty list of student names
    quizSessions[code] = {
        quizId: quizId,
        studentNames: []
    };

    // Send a success response
    res.status(200).json({ message: 'Quiz session created' });
});

app.get('/quizPage', function(req, res) {
    const code = req.query.code;
    // You can now use the code to get the quiz session
    // and send the relevant data to the client

    // Send the quizpage.html file
    res.sendFile(path.join(__dirname, '../frontend/quizpage.html'));
});


app.post('/joinQuizSession', function(req, res) {
    // Get the code and username from the request body
    let code = req.body.code;
    let username = req.body.username;

    // Check if the quiz session exists
    if (!quizSessions[code]) {
        res.status(400).send('Invalid code');
        return;
    }

    // Add the username to the studentNames array of the quiz session
    quizSessions[code].studentNames.push(username);

    // Send a success response
    res.status(200).json({ message: 'Joined quiz session' });
});



app.post('/teacher-login', function(req, res) {
    const { username, password } = req.body;

    if (username === 'admin' && password === 'admin') {
        req.session.user = username;
        req.session.role = 'teacher';
        res.redirect('/teacherDashboard');
    } else {
        res.status(400).send('Invalid username or password');
    }
});

app.post('/data', function(req, res) {
    if (req.isAuthenticated()) {
        users[req.user].data.push(req.body);
        res.status(200).send('Data received');
    } else {
        res.status(401).send('You need to log in first');
    }
});

// Get the network interfaces
const networkInterfaces = os.networkInterfaces();

// Get the IPv4 address
let ipv4;
for (let interface of Object.values(networkInterfaces)) {
    for (let connection of interface) {
        if (connection.family === 'IPv4' && !connection.internal) {
            ipv4 = connection.address;
            break;
        }
    }
    if (ipv4) break;
}

const path = require('path');


app.get('/getQuiz', function(req, res) {
    let filepath = path.join(__dirname, './quizzes.json');

    fs.readFile(filepath, 'utf8', function(err, data) {
        if (err) {
            console.error(err);
            return res.status(500).send('An error occurred reading the file.');
        }

        res.json(JSON.parse(data));
    });
});

app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
});

app.get('/teacherDashboard', checkTeacherLoggedIn, function(req, res) {
    res.sendFile(path.join(__dirname, '..', 'frontend', 'private', 'teacherDashboard.html'));
});

app.get('/studentDashboard', checkStudentLoggedIn, function(req, res) {
    res.sendFile(path.join(__dirname, '..', 'frontend', 'private', 'studentDashboard.html'));
});

app.get('/createQuiz', checkTeacherLoggedIn, function(req, res) {
    res.sendFile(path.join(__dirname, '..', 'frontend', 'private', 'createQuiz.html'));
});

// Serve static files
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Listen on the IPv4 address
app.listen(3000, ipv4, () => {
    console.log(`Server running at http://${ipv4}:3000/`);
});

function checkTeacherLoggedIn(req, res, next) {
    if (req.session && req.session.user && req.session.role === 'teacher') {
        next();
    } else {
        res.redirect('/index.html');
    }
}

function checkStudentLoggedIn(req, res, next) {
    if (req.session && req.session.user && req.session.role === 'student') {
        next();
    } else {
        res.redirect('/index.html');
    }
}